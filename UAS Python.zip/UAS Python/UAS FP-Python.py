from tkinter import *

#Class
class menghitung:
    def __init__(self,window):    

        #Membuat MainWindow !
        self.window = window
        self.window.title("Aplikasi Konverter Suhu")
        self.window.geometry("300x400")
        self.window.resizable(False, False)

        ftc = StringVar()
        ftk = StringVar()
        ctf = StringVar()
        ctk = StringVar()
        ktc = StringVar()
        ktf = StringVar()
            
        #Rumus Perhitungan !
        def fahrenheit_to_celsius():
            # Konversi nilai Fahrenheit ke Celcius dan masukan hasil ke dalam lbl_result1.
            FTC = float(ftc.get())
            celsius = (5/9) * (float(FTC) - 32)
            self.lbl_result1.config(text = f"{round(celsius, 2)} \N{DEGREE CELSIUS}")
        def fahrenheit_to_kelvin():
            # Konversi nilai Fahrenheit ke Kelvin dan masukan hasil ke dalam lbl_result2.
            FTK = float(ftk.get())
            kelvin = (5/9) * (float(FTK) - 32) + 273
            self.lbl_result2.config(text = f"{round(kelvin, 2)} \N{KELVIN SIGN}")
        def celcius_to_fahrenheit():
            # Konversi nilai Celcius ke Fahrenheit dan masukan hasil ke dalam lbl_result3.
            CTF = float(ctf.get())
            fahrenheit = ((9/5) * float(CTF)) + 32
            self.lbl_result3.config(text = f"{round(fahrenheit, 2)} \N{DEGREE FAHRENHEIT}")
        def celcius_to_kelvin():
            # Konversi nilai Celcius ke Kelvindan masukan hasil ke dalam lbl_result4.
            CTK = float(ctk.get())
            kelvin = float(CTK) + 273
            self.lbl_result4.config(text = f"{round(kelvin, 2)} \N{KELVIN SIGN}")
        def kelvin_to_celsius():
            # Konversi nilai Kelvin ke Celcius dan masukan hasil ke dalam lbl_result5.
            KTC = float(ktc.get())
            celsius = float(KTC) - 273
            self.lbl_result5.config(text = f"{round(celsius, 2)} \N{DEGREE CELSIUS}")
        def kelvin_to_fahrenheit():
            # Konversi nilai Kelvin ke Fahrenheit dan masukan hasil ke dalam lbl_result6.
            KTF = float(ktf.get())
            fahrenheit = ((9/5) * (float(KTF) - 273)) + 32
            self.lbl_result6.config(text = f"{round(fahrenheit, 2)} \N{DEGREE FAHRENHEIT}")

        #Reset Here !
        def reset():
            ftc.set("")
            ftk.set("")
            ctf.set("")
            ctk.set("")
            ktc.set("")
            ktf.set("")
            
            self.lbl_result1.config(text = "\N{DEGREE CELSIUS}")
            self.lbl_result2.config(text = "\N{KELVIN SIGN}")
            self.lbl_result3.config(text = "\N{DEGREE FAHRENHEIT}")
            self.lbl_result4.config(text = "\N{KELVIN SIGN}")
            self.lbl_result5.config(text = "\N{DEGREE CELSIUS}")
            self.lbl_result6.config(text = "\N{DEGREE FAHRENHEIT}")

        #Judul Aplikasi !
        self.Judul = Label(window, text = "Konverter Suhu")
        self.Judul.pack()
        self.Judul.config(font = ("Bahnschrift", 20, "bold"))
        
        #Membuat Entry Frame dengan Entry dan beri label suhu yang ingin di konversi
        self.frm_entry1 = Frame(master=self.window)
        self.frm_result1 = Frame(master=self.window)
        
        self.frm_entry2 = Frame(master=self.window)
        self.frm_result2 = Frame(master=self.window)

        self.frm_entry3 = Frame(master=self.window)
        self.frm_result3 = Frame(master=self.window)

        self.frm_entry4 = Frame(master=self.window)
        self.frm_result4 = Frame(master=self.window)

        self.frm_entry5 = Frame(master=self.window)
        self.frm_result5 = Frame(master=self.window)

        self.frm_entry6 = Frame(master=self.window)
        self.frm_result6 = Frame(master=self.window)

        self.frm_entry7 = Frame(master=self.window)
        
        #Mengatur Letak label + Entry   
        self.ent_temperature1 = Entry(master=self.frm_entry1, width=20, textvariable = ftc)
        self.lbl_temp1 = Label(master=self.frm_entry1, text="\N{DEGREE FAHRENHEIT}")

        self.ent_temperature2 = Entry(master=self.frm_entry2, width=20, textvariable = ftk)
        self.lbl_temp2 = Label(master=self.frm_entry2, text="\N{DEGREE FAHRENHEIT}")

        self.ent_temperature3 = Entry(master=self.frm_entry3, width=20, textvariable = ctf)
        self.lbl_temp3 = Label(master=self.frm_entry3, text="\N{DEGREE CELSIUS}")

        self.ent_temperature4 = Entry(master=self.frm_entry4, width=20, textvariable = ctk)
        self.lbl_temp4 = Label(master=self.frm_entry4, text="\N{DEGREE CELSIUS}")

        self.ent_temperature5 = Entry(master=self.frm_entry5, width=20, textvariable = ktc)
        self.lbl_temp5 = Label(master=self.frm_entry5, text="\N{KELVIN SIGN}")

        self.ent_temperature6 = Entry(master=self.frm_entry6, width=20, textvariable = ktf)
        self.lbl_temp6 = Label(master=self.frm_entry6, text="\N{KELVIN SIGN}")

        #Tombol Konversi, label Tampilan, Hasil konversi dan Tombol Reset
        self.btn_convert1 = Button(master=self.frm_entry1,text="->",width=5,command=fahrenheit_to_celsius)
        self.lbl_result1 = Label(master=self.frm_result1, text="\N{DEGREE CELSIUS}")

        self.btn_convert2 = Button(master=self.frm_entry2,text="->",width=5,command=fahrenheit_to_kelvin)
        self.lbl_result2 = Label(master=self.frm_result2, text="\N{KELVIN SIGN}")

        self.btn_convert3 = Button(master=self.frm_entry3,text="->",width=5,command=celcius_to_fahrenheit)
        self.lbl_result3 = Label(master=self.frm_result3, text="\N{DEGREE FAHRENHEIT}")

        self.btn_convert4 = Button(master=self.frm_entry4,text="->",width=5,command=celcius_to_kelvin)
        self.lbl_result4 = Label(master=self.frm_result4, text="\N{KELVIN SIGN}")

        self.btn_convert5 = Button(master=self.frm_entry5,text="->",width=5,command=kelvin_to_celsius)
        self.lbl_result5 = Label(master=self.frm_result5, text="\N{DEGREE CELSIUS}")

        self.btn_convert6 = Button(master=self.frm_entry6,text="->",width=5,command=kelvin_to_fahrenheit)
        self.lbl_result6 = Label(master=self.frm_result6, text="\N{DEGREE FAHRENHEIT}")

        self.btn_reset = Button(master=self.frm_entry7,text="Reset",width=30,command=reset)

        # Set-up layout Menggunakan Place 
        self.ent_temperature1.place(x = 25, width = 60)
        self.lbl_temp1.place(x = 85)
        self.frm_entry1.place(width = 170, height = 30, y = 50)
        self.btn_convert1.place(x = 130, width = 40)
        self.lbl_result1.place(x = 5, width = 120)
        self.frm_result1.place(width = 130, height = 30, y = 50, x = 170)

        self.ent_temperature2.place(x = 25, width = 60)
        self.lbl_temp2.place(x = 85)
        self.frm_entry2.place(width = 170, height = 30, y = 100)
        self.btn_convert2.place(x = 130, width = 40)
        self.lbl_result2.place(x = 5, width = 120)
        self.frm_result2.place(width = 130, height = 30, y = 100, x = 170)

        self.ent_temperature3.place(x = 25, width = 60)
        self.lbl_temp3.place(x = 85)
        self.frm_entry3.place(width = 170, height = 30, y = 150)
        self.btn_convert3.place(x = 130, width = 40)
        self.lbl_result3.place(x = 5, width = 120)
        self.frm_result3.place(width = 130, height = 30, y = 150, x = 170)

        self.ent_temperature4.place(x = 25, width = 60)
        self.lbl_temp4.place(x = 85)
        self.frm_entry4.place(width = 170, height = 30, y = 200)
        self.btn_convert4.place(x = 130, width = 40)
        self.lbl_result4.place(x = 5, width = 120)
        self.frm_result4.place(width = 130, height = 30, y = 200, x = 170)

        self.ent_temperature5.place(x = 25, width = 60)
        self.lbl_temp5.place(x = 85)
        self.frm_entry5.place(width = 170, height = 30, y = 250)
        self.btn_convert5.place(x = 130, width = 40)
        self.lbl_result5.place(x = 5, width = 120)
        self.frm_result5.place(width = 130, height = 30, y = 250, x = 170)

        self.ent_temperature6.place(x = 25, width = 60)
        self.lbl_temp6.place(x = 85)
        self.frm_entry6.place(width = 170, height = 30, y = 300)
        self.btn_convert6.place(x = 130, width = 40)
        self.lbl_result6.place(x = 5, width = 120)
        self.frm_result6.place(width = 130, height = 30, y = 300, x = 170)

        self.frm_entry7.place(width = 300, height = 30, y = 350)
        self.btn_reset.place(width = 280, x = 10)

        self.label_copyright = Label(window, text = "@Copyright by Edo_0441,Daffa_0453,Reza_0433 !!!")
        self.label_copyright.place(relx=0 ,rely=1,anchor=SW)

#Jalankan Aplikasi !
if __name__=='__main__':
    window = Tk()
    application = menghitung(window)
    photo = PhotoImage(file = 'suhu.png')
    window.iconphoto(False, photo)
    window.mainloop()
